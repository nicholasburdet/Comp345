This is the Map Observer of Assignment 2.
It uses the latest version of QT, 5.7
