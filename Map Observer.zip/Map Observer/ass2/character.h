#ifndef MYRECT_H
#define MYRECT_H

#include <QGraphicsRectItem>

class character : public QGraphicsPixmapItem {
public:
	void keyPressEvent(QKeyEvent * event);

};


#endif