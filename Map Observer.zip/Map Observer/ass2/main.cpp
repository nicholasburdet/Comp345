#include "character.h"

#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsView>

int main(int argc, char *argv[])
{

	//Initilize QT Application and images
	QApplication a(argc, argv);
	QImage image("includes/grass.png");
	QPixmap playerImage("includes/player.png");
	
	//Create and adds bg to screen
	QGraphicsPixmapItem* bg = new QGraphicsPixmapItem(QPixmap::fromImage(image));
	QGraphicsScene* scene = new QGraphicsScene;
	scene->addItem(bg);

	//Create and adds player to screen
	character * player = new character();
	player->setPixmap(playerImage);
	scene->addItem(player);
	player->setFlag(QGraphicsItem::ItemIsFocusable);
	player->setFocus();

	//Creates and adds scene
	QGraphicsView view(scene);
	view.show();
	

	return a.exec();
}
