/********************************************************************************
** Form generated from reading UI file 'ass2.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ASS2_H
#define UI_ASS2_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ass2Class
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *ass2Class)
    {
        if (ass2Class->objectName().isEmpty())
            ass2Class->setObjectName(QStringLiteral("ass2Class"));
        ass2Class->resize(600, 400);
        menuBar = new QMenuBar(ass2Class);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        ass2Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(ass2Class);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        ass2Class->addToolBar(mainToolBar);
        centralWidget = new QWidget(ass2Class);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        ass2Class->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(ass2Class);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        ass2Class->setStatusBar(statusBar);

        retranslateUi(ass2Class);

        QMetaObject::connectSlotsByName(ass2Class);
    } // setupUi

    void retranslateUi(QMainWindow *ass2Class)
    {
        ass2Class->setWindowTitle(QApplication::translate("ass2Class", "ass2", 0));
    } // retranslateUi

};

namespace Ui {
    class ass2Class: public Ui_ass2Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ASS2_H
