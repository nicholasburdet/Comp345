
/*
Author: SHIHAO NING
Id: 27112009
Course: COMP 345
Assignment 2 Part 4: Map builder and adapt level of npc/items

Editscreen header file

Cause I did dice part in assignment1, so I borrowed map code from Nicholas, and I created adaptNpcLevel, adaptItemLevel for my part.
If you like to see my part, you can CTRL+F to search my name(shihao ning).
I put my name beside my code


*/

#include <QWidget>
#include <QGraphicsScene>
#include <QMainWindow>
#include <string>
#include <QMessageBox>

using namespace std;

class logic;

class editscreen : public QMainWindow {
	Q_OBJECT
public:
	editscreen(char n[]);
public slots:
	void editMap();
	void openMap();
	void newMap();
	void nextMap();
	void previousMap();
	void resetMap();
	void mapMenuClose();
	void newCampaign();
	void loadCampaign();
	void adaptNpcLevel(); //(edit by shihao ning)
	void adaptItemLevel(); //(edit by shihao ning)
	void createCampaignMenus();
	void campaignMenuClose();
private:
	logic *log;
	int checkResolution(int w, int h);
	void createMainMenu();
	void createEditorMenus();

	string fName;
	string campaignfName;
	int choice = 0;
	int clevel = 0; //(edit by shihao ning)
	int ilevel = 0; //(edit by shihao ning)

	bool campaignCreation = false;
	bool logicPersistence = false;
	bool openingMap = false;
	string currentMenu = "main";

	QMenu *editMenu;
	QMenu *mapMenu;
	QMenu *campaignMenu;
	QMenu *mapNavigatorMenu;
	

	QAction *campaignMenuAction;
	QAction *newCampaignAction;
	QAction *openCampaignAction;
	QAction *newMapAction;
	QAction *openMapAction;
	QAction *nextMapAction;
	QAction *previousMapAction;
	QAction *resetMapAction;
	QAction *mapMenuCloseAction;
	QAction *campaignMenuCloseAction;
	QAction *adaptNpcLevelAction; //(edit by shihao ning)
	QAction *adaptItemLevelAction; //(edit by shihao ning)
};