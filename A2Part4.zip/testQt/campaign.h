
/*
Author: SHIHAO NING
Id: 27112009
Course: COMP 345
Assignment 2 Part 4: Map builder and adapt level of npc/items

Campaign header file

Cause I did dice part in assignment1, so I borrowed map code from Nicholas, and I created adaptNpcLevel, adaptItemLevel for my part.
If you like to see my part, you can CTRL+F to search my name(shihao ning).
I put my name beside my code



*/

#pragma once
#include <string>
#include "MapScreen.h"
#include <vector>

using namespace std;

//Structure that holds references to campaign map IDs and their fileNames
struct mapReference
{
	int mapIdentifier;
	string mapFileName;
};

class campaign
{
public:
	campaign();
	void loadCampaign(string filename);
	void saveCampaign();
	void setId(int i);
	void setName(string n);
	void setNumberOfMaps(int m);
	void setCurrentMapId(int i);

	string getMapFilename(int i);
	int getId();
	string getName();
	int getNumberOfMaps();
	int getCurrentMapId();

	void addMap(string filename);
private:
	vector<mapReference> mapVector;
	int numberOfMaps = 0;
	string name;
	int id;
	int currentMapId = 0;
};

