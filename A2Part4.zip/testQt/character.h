#pragma once

/*
Author: SHIHAO NING
Id: 27112009
Course: COMP 345
Assignment 2 Part 4: Map builder and adapt level of npc/items

Character header file

Cause I did dice part in assignment1, so I borrowed map code from Nicholas, and I created adaptNpcLevel, adaptItemLevel for my part.
If you like to see my part, you can CTRL+F to search my name(shihao ning).
I put my name beside my code

*/

#pragma once
#include <string>
using namespace std;

class character
{
public:
	character();
	character(int i, string n, int l, string im);
	void setId(int i);
	void setName(string n);
	void setLevel(int l);
	void setImage(string im);

	void setX(int x);
	void setY(int y);

	int getId();
	string getName();
	int getLevel();
	string getImage();

	int getX();
	int getY();
private:
	int id;
	string name = "NULL";
	int level;
	string image;
	int xPosition = -1;
	int yPosition = -1;
};
#pragma once
