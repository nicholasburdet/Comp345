#pragma once

/*
Author: SHIHAO NING
Id: 27112009
Course: COMP 345
Assignment 2 Part 4: Map builder and adapt level of npc/items

character cpp file

Cause I did dice part in assignment1, so I borrowed map code from Nicholas, and I created adaptNpcLevel, adaptItemLevel for my part.
If you like to see my part, you can CTRL+F to search my name(shihao ning).
I put my name beside my code

*/

#include "character.h"

character::character()
{

}
character::character(int i, string n, int l, string im) 
{
	id = i;
	name = n;
	level = l;
	image = im;
}

void character::setId(int i)
{
	id = i;
}
void character::setName(string n)
{
	name = n;
}
void character::setLevel(int l)
{
	level = l;
}
void character::setImage(string im)
{
	image = im;
}
void character::setX(int x)
{
	xPosition = x;
}
void character::setY(int y)
{
	yPosition = y;
}


int character::getId()
{
	return id;
}
string character::getName()
{
	return name;
}
int character::getLevel()
{
	return level;
}
string character::getImage()
{
	return image;
}
int character::getX()
{
	return xPosition;
}
int character::getY()
{
	return yPosition;
}