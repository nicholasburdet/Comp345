Author: SHIHAO NING
Id: 27112009
Course: COMP 345
Assignment 2 Part 4: Map builder and adapt level of npc/items

Cause I did dice part in assignment1, so I borrowed map code from Nicholas Burdet, and I created my code for adapt the level of npc and level of item.
I put my name beside my code if you like to see my part, you can CTRL+F to search my name(shihao ning).

you can open map in the "mapMenu"
you can find two adapt methods in the "mapNavigatorMenu"