
#pragma once

#include <iostream>
#include <stdio.h>

using namespace std;

class Dice
{
public: 
	static int roll(string string);//the string should be entered as xdy+z format
};