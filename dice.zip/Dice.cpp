#include "Dice.h"
#include <iostream>
#include <string>
using namespace std;

int Dice::roll(string string)
{
	string str;
	cin >> str;
	
	int x=string[0];// number of dice
	int y=string[3];//the type of the dice
	int z=0;//modifier 
	
	cout << x << y<<endl;


	

	return 1;
}
