#include <string>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include "itemContainer.h"



int main() {

	itemContainer ic;

	//// Removes item from backback based on ID
	//ic.removeItemBackpack(1);

	//// Adds item to backback from items based on ID
	//ic.addItemBackpack(232);

	//// Returns item Bonus
	//ic.getBonus("includes/backpack.txt", 1);
	
	//// Returns item Type
	//ic.getType("includes/backpack.txt", 2);

	//// Returns item Name
	//ic.getName("includes/backpack.txt", 1);

	//// Returns item Enchantment
	//ic.getEnchantment("includes/backpack.txt", 2);

	//// Returns dice value or armor grade
	//ic.getDiceOrGrade("includes/backpack.txt",3);

	//// Replaces worn item with id of new item
	//ic.addItemWorn(3);
	
	//// Removes worn itemtype
	//ic.removeItemWorn("Helmet");

	return 0;
}