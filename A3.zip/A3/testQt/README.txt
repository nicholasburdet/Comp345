This is shihao NING, ID:27112009

I implement a game logger in this project for assignment 3 part 4. 
This project requires QT library.

Most of my code are located in "editscreen" file and "logic" file.
You can search my name "shihao ning" to see exactly where it is.
I make a new menubar that switch on/off any of the different logging 
Also, you can set all of them on/off.
The default setting is that all of them are on. 

When you run this project, first click Main menu and choose game start, then you can pick any of a campaign and choose one hero file.
After this, you can use up,down,left,right to control hero's move, you can press "A" as attack and will see the attackLog display detail
But after pressed A, player's turn is end. Now you need to Press "N" to allow Npc moving toward your hero, you may press "N" severl times until all NPC have moved
Also, you can press "S" to see a dice roll and will display the diceLog detail during your turn, it results in ending player turn as well.