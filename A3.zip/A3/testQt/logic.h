/*
Author: Shihao Ning
Id: 27112009
Course: COMP 345
Assignment 3 Part 4:  Game logger as Observer

I implement my code based on code from our project, and I created Game logger for my part.
If you like to see my part, you can CTRL+F to search my name(shihao ning).
I put my name beside my code

Logic header file
*/

#ifndef LOGIC_H
#define LOGIC_H


#include <QWidget>
#include "MapScreen.h"
#include "playerLog.h"
#include "Campaign.h"
#include <string>
#include <QMessageBox>
#include <vector>
#include "character.h"
#include <QMainWindow>

using namespace std;

class logic : public QWidget
{
	Q_OBJECT;
	public:
		logic(QWidget *parent = 0, QMainWindow *mw = 0);
		void initialize(int w, int h, string n);
		void newCampaign(string cName, int cId);
		void loadCampaign(string filename);
		void loadJustCampaign();
		void loadPlayerCharacter(string filename);
		void setResolution(int res);

		void setAllLogDisplayOn();//set all log detail on, created by shihao NING
		void setAllLogDisplayOff();//set all log detail off
		void setGameLogDisplayOn();//set game log detail on
		void setGameLogDisplayOff();//set game log detail off
		void setAttackLogDisplayOn();//set attack log detail on
		void setAttackLogDisplayOff();//set attack log detail off
		void setDiceLogDisplayOn();//set dice log detail on
		void setDiceLogDisplayOff();//set dice log detail off, created by shihao NING

		void loadMap(string filename);
		void newMap();
		bool previousMap();
		bool nextMap();
		void resetMap(int w, int h);
		int getWidth();
		int getHeight();
		string getFilename();
		void closeWindow();
		void setEditmode(bool editM);
		int checkResolution(int x, int y);
	protected:
		void mousePressEvent(QMouseEvent *event) Q_DECL_OVERRIDE;
		void paintEvent(QPaintEvent *event) Q_DECL_OVERRIDE;
		void keyPressEvent(QKeyEvent *event) Q_DECL_OVERRIDE;
		void resizeEvent(QResizeEvent *event) Q_DECL_OVERRIDE;
		void leaveEvent(QEvent * event) Q_DECL_OVERRIDE;
		void changeEvent(QEvent * event) Q_DECL_OVERRIDE;
		void focusOutEvent(QFocusEvent * event) Q_DECL_OVERRIDE;
		void enterEvent(QEvent * event) Q_DECL_OVERRIDE;
	private:
		QPoint lastPoint = QPoint(0,0);
		QImage image;
		QMessageBox message;
		QFont font;

		//flag to invoke fullscreen painter and initialization (also incase contents of screen disappear)
		bool start = true;
		bool editMode = true;

		MapScreen ms;
		
		campaign Campaign;
		int resolution = 50;

		//flag each time users clicks on screen to invoke mouse event
		bool clicked = false;

		int currentX;
		int currentY;
		QPixmap currentTile = QPixmap("C:/Users/Nick/Desktop/Images/grass.png");
		
		//This will be the mode checking for tiles
		int mode = 1; 
		
		//This will be in coupling with the mode, the determining factor for the NPC
		int npcId = 0;

		//flags to indicate the user is drawing entrance or exit
		bool drawStart = false; 
		bool drawEnd = false;
		bool drawNPC = false;
		bool movePlayer = false;
		bool replacePlayer = false;

		//flag to check path status
		bool checkStatus = true;

		//stores if path exists here, default map path exists
		bool path = true;

		bool textChange = false;

		bool gamelogDisplay = true;//created by shihao NING
		bool attacklogDisplay = true;//created by shihao NING
		bool dicelogDisplay = true;//created by shihao NING

		//values to hold previous entrance or exit when painting new ones to fill in old spaces
		int oldStartX;
		int oldStartY;
		int oldEndX;
		int oldEndY;

		int oldPlayerX;
		int oldPlayerY;
		string replace = "";

		int wid;
		int hei;

		//this section will hold some variables pertaining to gameplay ONLY, ignore for non-gameplay related stuff
		int playerSteps = 0;
		bool gameSession = false;

		
		playerLog combatLog;//this store all log detail
		bool playerTurn = true;
		int npcTurn = 0;
		QMainWindow *mainWindow;
};

#endif
