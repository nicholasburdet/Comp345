/*
Author: Alexis Grondin
Id : 26639569
Course : COMP 345
Assignment 2 Part 2 : Character Observer

 Observer abstract class
*/

#include "observer.h"



observer::observer()
{
}


observer::~observer()
{
}


