/*
Author: Shihao Ning
Id: 27112009
Course: COMP 345
Assignment 3 Part 4:  Game logger as Observer

I implement my code based on code from our project, and I created Game logger for my part.
If you like to see my part, you can CTRL+F to search my name(shihao ning).
I put my name beside my code

Editscreen header file
*/

#include <QWidget>
#include <QGraphicsScene>
#include <QMainWindow>
#include <string>
#include <QMessageBox>
#include "character.h"
#include "characterObserver.h"
#include "characterController.h"



using namespace std;

class logic;

class editscreen : public QMainWindow {
	Q_OBJECT
public:
	editscreen(char n[]);
public slots:
	void editMap();
	void openMap();
	void newMap();
	void nextMap();
	void previousMap();
	void resetMap();
	void mapMenuClose();
	void newCampaign();
	void loadCampaign();
	void createCampaignMenus();
	void menuClose();
	void createCharacterMenus();
	void characterEditorMenu();
	void characterEditorSave();
	void loadCharacter();
	void viewCharacterStats();
	void viewMap();
	
	void viewBackpack();
	void viewWornItems();

	void enableAllLogDisplay();//created by shihao NING
	void disableAllLogDisplay();

	void enableGameLogDisplay();
	void disableGameLogDisplay();
	void enableAttackLogDisplay();
	void disableAttackLogDisplay();
	void enableDiceLogDisplay();
	void disableDiceLogDisplay();//created by shihao NING

	////For Item && Character movement
	void newItem();
	void newGameMap();
	////
private:
	logic *log;
	character *newCharacter = new character();
	int checkResolution(int w, int h);
	void createMainMenu();
	void createEditorMenus();

	string fName;
	string campaignfName;
	int choice = 0;

	bool campaignCreation = false;
	bool logicPersistence = false;
	bool openingMap = false;
	bool viewingMap = false; //For simply viewing the map without edits
	string currentMenu = "main";

	QMenu *editMenu;
	QMenu *mapMenu;
	QMenu *campaignMenu;
	QMenu *mapNavigatorMenu;
	QMenu *characterMenu;
	QMenu *characterCreatorMenu;
	QMenu *gameMenu;
	QMenu *logMenu;

	QAction *campaignMenuAction;
	QAction *newCampaignAction;
	QAction *openCampaignAction;
	QAction *newMapAction;
	QAction *openMapAction;
	QAction *nextMapAction;
	QAction *previousMapAction;
	QAction *resetMapAction;
	QAction *mapMenuCloseAction;
	QAction *menuCloseAction;
	QAction *characterMenuAction;
	QAction *characterEditorMenuAction;
	QAction *characterLoadMenuAction;
	QAction *characterEditorSaveAction;
	QAction *viewCharacterStatsAction;
	QAction *viewMapAction;
	
	QAction *viewBackpackAction;
	QAction *viewWornItemsAction;

	////Item Action && Character movement
	QAction *newItemAction;
	QAction *newMoveableMapAction;
	
	//// Game logger to display all game info,created by shihao ning
	QAction *enableAllLogDisplayAction;//display all log info
	QAction *disableAllLogDisplayAction;
	QAction *enableGameLogDisplayAction;//display game log info
	QAction *disableGameLogDisplayAction;
	QAction *enableAttackLogDisplayAction;//display attack log info
	QAction *disableAttackLogDisplayAction;
	QAction *enableDiceLogDisplayAction;//display dice log info
	QAction *disableDiceLogDisplayAction;
	

};
