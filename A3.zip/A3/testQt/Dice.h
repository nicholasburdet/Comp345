
#pragma once

#include <iostream>
#include <stdio.h>

using namespace std;

class Dice
{
public: 
	static int roll(int quantity, int type, int modifier);
};